SELECT j.nev AS "Név",
       COUNT(*) AS "Piros lapok száma"
FROM Buntetes b JOIN Jatekos j ON b.jatekos_id = j.jatekos_id
WHERE b.lap = 'Piros'
GROUP BY j.jatekos_id
ORDER BY COUNT(*) DESC;

SELECT s.nev AS "Stadion neve",
       SUM(m.nezoszam) AS "Összes nézőszám"
FROM Merkozes m JOIN Stadionok s ON m.helyszin_id = s.stadion_id
GROUP BY s.nev

--GROUPING_ID, GROUPING és ROLLUP sincs, nem tudom sqllite-ban tesztelni 
SELECT
  CASE GROUPING_ID(s.nev, cs.nev)
    WHEN 1 THEN "Részösszeg"
    WHEN 3 THEN "Végösszeg"
    ELSE s.nev
  END AS "Stadion",
  IIF(GROUPING(cs.nev) = 1,"Részösszeg",cs.nev) AS "Csapat",
  SUM(
    CASE
      WHEN m.hazai_csapat_id = cs.csapat_id THEN m.hazai_gol
      WHEN m.vendeg_csapat_id = cs.csapat_id THEN m.vendeg_gol
      ELSE 0
    END
  ) AS osszes_gol
FROM Merkozes m JOIN Stadionok s ON m.helyszin_id = s.stadion_id
				JOIN Csapat cs ON cs.csapat_id IN (m.hazai_csapat_id, m.vendeg_csapat_id)
GROUP BY ROLLUP(s.nev, cs.nev)

--hasonló helyzet, mint az előzőnél, de ezt talán egy fokkal könnyebb fejben is leellenőrizni
SELECT s.nev AS "Stadion",
       cs.nev "Csapat",
       SUM(hazai_gol) AS "Összes gól"
FROM Merkozes m JOIN Stadionok s on m.helyszin_id = s.stadion_id
			    JOIN Csapat cs ON m.hazai_csapat_id = cs.csapat_id
GROUP BY GROUPING SETS ((helyszin_id),(hazai_csapat_id));

SELECT m.datum AS "Mérrkőzés dátuma",
       j.nev AS "Játékos",
       s.nev AS "Stadion",
       g.perc AS "Gól ideje (perc)",
       COUNT(*) OVER (PARTITION BY g.merkozes_id ORDER BY g.perc ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS "Eddigi gólok száma"
FROM Gol g JOIN Merkozes m ON g.merkozes_id = m.merkozes_id
		   JOIN Stadionok s ON m.helyszin_id = s.stadion_id
		   JOIN Jatekos j ON g.jatekos_id = j.jatekos_id
ORDER BY m.datum

--Leggyorsabb gólok
SELECT m.datum AS "Dátum",
       j.nev AS "Játékos",
       cs.nev AS "Csapat",
       g.perc AS "Perc"
FROM Gol g join Merkozes m on g.merkozes_id = m.merkozes_id
	       JOIN Jatekos j on g.jatekos_id = j.jatekos_id
           JOIN Csapat cs ON j.csapat_id = cs.csapat_id
ORDER BY g.perc ASC
LIMIT 10;

SELECT j.nev AS "Név",
       COUNT(*) AS "Gólok száma"
FROM Gol g JOIN Jatekos j on g.jatekos_id = j.jatekos_id
GROUP BY g.jatekos_id
ORDER BY COUNT(*) DESC
LIMIT 10;