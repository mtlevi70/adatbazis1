CREATE TABLE Csapat (
    csapat_id INTEGER PRIMARY KEY,
    nev VARCHAR(100),
    varos VARCHAR(100),
    datum DATE
);

CREATE TABLE Jatekos (
    jatekos_id INTEGER PRIMARY KEY,
    nev VARCHAR(100),
    szuletesi_datum DATE,
    poszt VARCHAR(50),
    csapat_id INTEGER,
    FOREIGN KEY (csapat_id) REFERENCES Csapat(csapat_id)
);

CREATE TABLE Merkozes (
    merkozes_id INTEGER PRIMARY KEY,
    datum DATE,
    helyszin_id INTEGER,
    nezoszam INTEGER,
    hazai_csapat_id INTEGER,
    vendeg_csapat_id INTEGER,
    hazai_gol INTEGER,
    vendeg_gol INTEGER,
    FOREIGN KEY (helyszin_id) REFERENCES Stadionok(stadion_id),
    FOREIGN KEY (hazai_csapat_id) REFERENCES Csapat(csapat_id),
    FOREIGN KEY (vendeg_csapat_id) REFERENCES Csapat(csapat_id)
);

CREATE TABLE Gol (
    gol_id INTEGER PRIMARY KEY,
    merkozes_id INTEGER,
    jatekos_id INTEGER,
    perc INTEGER,
    FOREIGN KEY (merkozes_id) REFERENCES Merkozes(merkozes_id),
    FOREIGN KEY (jatekos_id) REFERENCES Jatekos(jatekos_id)
);

CREATE TABLE Buntetes (
    buntetes_id INTEGER PRIMARY KEY,
    merkozes_id INTEGER,
    jatekos_id INTEGER,
    lap VARCHAR(10) NOT NULL CHECK (LOWER(lap) IN ('sárga', 'piros')),
    perc INTEGER,
    FOREIGN KEY (merkozes_id) REFERENCES Merkozes(merkozes_id),
    FOREIGN KEY (jatekos_id) REFERENCES Jatekos(jatekos_id)
);
CREATE TABLE Stadionok (
    stadion_id INTEGER PRIMARY KEY,
    nev VARCHAR(100),
    max_nezoszam INT,
    varos VARCHAR(50)
);